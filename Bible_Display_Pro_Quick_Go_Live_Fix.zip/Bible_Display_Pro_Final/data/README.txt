KJV DATABASE
============
Place the complete validated KJV database at data/kjv.json.
The expected database has 66 books, 1,189 chapters and 31,102 verses.
If you already have a working data/kjv.json, copy it here to preserve offline use.
If not, run setup_kjv.py with an internet connection once; the installer downloads,
validates, and saves the public-domain KJV dataset before the app can launch.
