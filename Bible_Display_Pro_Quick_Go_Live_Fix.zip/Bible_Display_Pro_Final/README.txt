BIBLE DISPLAY PRO — COMPLETE APP PACKAGE
========================================

Purpose
-------
A local-first KJV scripture controller and transparent OBS output for Windows.
Uses Python's standard library only; no pip packages or paid services are needed.

FEATURES
--------
- KJV book/chapter/verse navigation and passage-range selection
- Full-text search and reference lookup (for example John 3:16 or Psalm 23:1-6)
- Controller preview separate from the live OBS output
- GO LIVE and CLEAR OUTPUT controls
- Permanently transparent OBS output (no output-background opacity slider)
- Text and scripture-reference color pickers
- 30 font choices, including Arial Rounded MT Bold, Comic Sans MS, Script MT Bold,
  Anton, Roboto, Open Sans, Lato, Montserrat, Poppins, Oswald, Bebas Neue,
  League Spartan, Playfair Display, Merriweather, Lobster, Pacifico, Dancing
  Script, Cinzel, Nunito, Raleway, Inter, Source Sans 3 and Quicksand, plus
  familiar Windows fonts
- First-run download of 20 redistributable Google Fonts families into local assets;
  downloaded fonts are served locally and remain available offline
- Font size/weight, alignment, vertical placement, width, padding, line spacing,
  letter spacing, shadow, outline, verse numbers, reference visibility and auto-fit
- Presets: save, load, delete, export and import
- Favorites, recent passages and a queue that persists in the controller browser
- Keyboard shortcuts: Enter searches; Space sends live; Esc clears; Alt+Left/Right
  moves through the queue
- Local health endpoint and explicit database validation/error reporting
- Runs locally; no account or cloud connection is required after setup

FIRST-TIME SETUP
----------------
1. Extract this entire folder to a normal folder such as Desktop\Bible_Display_Pro.
2. Install Python 3 for Windows from https://www.python.org/downloads/windows/ if needed.
   During setup, enable Add Python to PATH.
3. Double-click start.bat.
4. If data\kjv.json is not already present, the installer needs internet once to
   download the public-domain KJV. It validates 66 books, 1,189 chapters and
   31,102 verses before saving the database.
5. On first launch, setup_fonts.py downloads 20 open-licensed font families from
   the official Google Fonts GitHub repository. This step needs internet access;
   after successful setup, those font files are local and work offline.
6. Keep the server's Command Prompt window open while using the controller/OBS.

IMPORTANT DATABASE NOTE
----------------------
The full KJV data file is not embedded in this ZIP because the build environment
could not retrieve the 6.44 MB upstream database. If your previous installation
has a working data\kjv.json, copy it into this package's data folder before
launching. Otherwise run setup_kjv.py (or Repair_KJV_Database.bat) while online.
The app does not pretend a partial Bible is complete: it checks the expected
book/chapter/verse counts and shows a useful error if validation fails. The data
loader also converts standard OSIS abbreviations (such as Gen and Ps) into the
full Bible book names used by the controller.

CONTROLLER / OBS SETUP
----------------------
Controller dock URL:
  http://127.0.0.1:8765/index.html

OBS Browser Source URL:
  http://127.0.0.1:8765/output.html
Set Browser Source dimensions to 1920 x 1080. Keep “Shutdown source when not
visible” disabled for smoother reconnection. Place the Bible source above the
background/camera layer. The output HTML/body/canvas backgrounds are locked to
transparent; only the scripture text and reference are drawn.

Useful checks:
  http://127.0.0.1:8765/api/health  — server/database status
  http://127.0.0.1:8765/api/state   — current live verse state
  http://127.0.0.1:8765/output.html — test output in a normal browser

FONT NOTES
----------
The first-run installer downloads 20 open-licensed Google Fonts families from
https://github.com/google/fonts and stores the font binaries and license files
under assets/fonts/. The app loads them using assets/fonts.css, so they work
offline after setup. If a download fails, run setup_fonts.py again when online.

Arial Rounded MT Bold, Comic Sans MS, and Script MT Bold are proprietary fonts
and are not redistributed by this package. They will render when available on
Windows; otherwise the browser will use a suitable fallback font. Anton and the
other Google Fonts are locally bundled after the setup download.

REPAIR / OTHER FILES
--------------------
- Repair_KJV_Database.bat: retry first-time database setup.
- validate_kjv.py: validate the local KJV file and exact verse counts.
- Open_Controller.bat: opens the controller URL (server must already be running).
- Open_Output_Test.bat: opens the output URL (server must already be running).
- setup_kjv.py: downloads and validates the public-domain KJV once.
- setup_fonts.py: downloads 20 open-licensed Google Fonts and creates local CSS.
- assets/fonts/: downloaded font binaries and their license notices.
- server.py: local HTTP and WebSocket server.

TROUBLESHOOTING
---------------
- Controller stuck loading: open http://127.0.0.1:8765/api/health and check the
  server window. If the database exists, the controller should validate it and
  report exact counts or a clear error.
- Missing/invalid Bible: run validate_kjv.py; if missing, copy a working database
  from your previous app or run Repair_KJV_Database.bat with internet access.
- Blank output: test http://127.0.0.1:8765/output.html, then refresh the OBS Browser
  Source. Ensure it points to output.html, not index.html.
- Port already in use: close any previous Bible Display Pro server window before
  starting a second instance.

DATA SOURCE
-----------
KJV dataset source: https://github.com/midvash/bible-data
The dataset source identifies the KJV text as public domain. Bible Display Pro is
an independent project and is not affiliated with OBS Studio.

This package has been syntax-checked and basic local endpoints tested. It has not
been certified on every Windows/OBS/browser combination, so “perfect on every
computer” cannot be guaranteed. Keep your previous folder until you confirm your
specific setup works.
